
package main;

//@utor: Yaret 

import java.util.Random;

public class MainFrame extends javax.swing.JFrame {

    public MainFrame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        bgA = new javax.swing.ButtonGroup();
        bgB = new javax.swing.ButtonGroup();
        bgC = new javax.swing.ButtonGroup();
        rbA1 = new javax.swing.JRadioButton();
        rbA2 = new javax.swing.JRadioButton();
        rbA3 = new javax.swing.JRadioButton();
        rbA4 = new javax.swing.JRadioButton();
        rbB1 = new javax.swing.JRadioButton();
        rbB2 = new javax.swing.JRadioButton();
        rbB3 = new javax.swing.JRadioButton();
        rbB4 = new javax.swing.JRadioButton();
        rbC1 = new javax.swing.JRadioButton();
        rbC2 = new javax.swing.JRadioButton();
        rbC3 = new javax.swing.JRadioButton();
        rbC4 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        bJugar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lbL1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lbL2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lbL3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgA.add(rbA1);
        rbA1.setText("1");
        rbA1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbA1ActionPerformed(evt);
            }
        });

        bgA.add(rbA2);
        rbA2.setText("2");
        rbA2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbA2ActionPerformed(evt);
            }
        });

        bgA.add(rbA3);
        rbA3.setText("3");
        rbA3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbA3ActionPerformed(evt);
            }
        });

        bgA.add(rbA4);
        rbA4.setText("4");
        rbA4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbA4ActionPerformed(evt);
            }
        });

        bgB.add(rbB1);
        rbB1.setText("1");
        rbB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbB1ActionPerformed(evt);
            }
        });

        bgB.add(rbB2);
        rbB2.setText("2");
        rbB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbB2ActionPerformed(evt);
            }
        });

        bgB.add(rbB3);
        rbB3.setText("3");
        rbB3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbB3ActionPerformed(evt);
            }
        });

        bgB.add(rbB4);
        rbB4.setText("4");
        rbB4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbB4ActionPerformed(evt);
            }
        });

        bgC.add(rbC1);
        rbC1.setText("1");
        rbC1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbC1ActionPerformed(evt);
            }
        });

        bgC.add(rbC2);
        rbC2.setText("2");
        rbC2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbC2ActionPerformed(evt);
            }
        });

        bgC.add(rbC3);
        rbC3.setText("3");
        rbC3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbC3ActionPerformed(evt);
            }
        });

        bgC.add(rbC4);
        rbC4.setText("4");
        rbC4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbC4ActionPerformed(evt);
            }
        });

        jLabel1.setText("A");

        jLabel2.setText("B");

        jLabel4.setText("C");

        bJugar.setText("Jugar");
        bJugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bJugarActionPerformed(evt);
            }
        });

        jLabel5.setText("Tus números");

        jLabel6.setText("Números ganadores");

        lbL1.setText("i");

        jLabel8.setText("j");

        lbL2.setText("i");

        jLabel10.setText("j");

        lbL3.setText("i");

        jLabel12.setText("j");

        jLabel13.setText("jLabel13");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbL1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lbL2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(28, 28, 28)
                                            .addComponent(lbL3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(bJugar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(50, 50, 50))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(rbA1)
                            .addComponent(rbA3)
                            .addComponent(rbA4)
                            .addComponent(rbA2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(rbB1)
                                    .addComponent(rbB3)
                                    .addComponent(rbB4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rbB2)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbC1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(rbC2, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(rbC3, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(rbC4, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel4))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(113, 113, 113)))
                .addContainerGap(132, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbC1)
                    .addComponent(rbB1)
                    .addComponent(rbA1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbA2)
                    .addComponent(rbB2)
                    .addComponent(rbC2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbB3)
                    .addComponent(rbC3)
                    .addComponent(rbA3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbC4)
                    .addComponent(rbA4)
                    .addComponent(rbB4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bJugar)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(19, 19, 19))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(lbL3)
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel8)
                                .addComponent(jLabel10))))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbL1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lbL2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bJugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bJugarActionPerformed
    
    //No sé cómo complementar esta parte, me hace falta añadir los números ganadores y después base a esto me marque si es ganador o perdedor. Tal cual el ejemplo del pdf...
    int max = 4;
    int min = 1; 
 
    Random random = new Random();
    int aleatorio = random.nextInt((max + min) - 1) + min;  
        
                
    }//GEN-LAST:event_bJugarActionPerformed

    private void rbA1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbA1ActionPerformed
        lbL1.setText(rbA1.getText());        
    }//GEN-LAST:event_rbA1ActionPerformed

    private void rbA2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbA2ActionPerformed
        lbL1.setText(rbA2.getText());        
    }//GEN-LAST:event_rbA2ActionPerformed

    private void rbA3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbA3ActionPerformed
        lbL1.setText(rbA3.getText());
    }//GEN-LAST:event_rbA3ActionPerformed

    private void rbA4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbA4ActionPerformed
        lbL1.setText(rbA4.getText());
    }//GEN-LAST:event_rbA4ActionPerformed

    private void rbB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbB1ActionPerformed
        lbL2.setText(rbB1.getText());  
    }//GEN-LAST:event_rbB1ActionPerformed

    private void rbB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbB2ActionPerformed
        lbL2.setText(rbB2.getText());
    }//GEN-LAST:event_rbB2ActionPerformed

    private void rbB3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbB3ActionPerformed
       lbL2.setText(rbB3.getText()); 
    }//GEN-LAST:event_rbB3ActionPerformed

    private void rbB4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbB4ActionPerformed
       lbL2.setText(rbB4.getText()); 
    }//GEN-LAST:event_rbB4ActionPerformed

    private void rbC1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbC1ActionPerformed
       lbL3.setText(rbC1.getText()); 
    }//GEN-LAST:event_rbC1ActionPerformed

    private void rbC2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbC2ActionPerformed
       lbL3.setText(rbC2.getText()); 
    }//GEN-LAST:event_rbC2ActionPerformed

    private void rbC3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbC3ActionPerformed
        lbL3.setText(rbC3.getText()); 
    }//GEN-LAST:event_rbC3ActionPerformed

    private void rbC4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbC4ActionPerformed
       lbL3.setText(rbC4.getText()); 
    }//GEN-LAST:event_rbC4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bJugar;
    private javax.swing.ButtonGroup bgA;
    private javax.swing.ButtonGroup bgB;
    private javax.swing.ButtonGroup bgC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel lbL1;
    private javax.swing.JLabel lbL2;
    private javax.swing.JLabel lbL3;
    private javax.swing.JRadioButton rbA1;
    private javax.swing.JRadioButton rbA2;
    private javax.swing.JRadioButton rbA3;
    private javax.swing.JRadioButton rbA4;
    private javax.swing.JRadioButton rbB1;
    private javax.swing.JRadioButton rbB2;
    private javax.swing.JRadioButton rbB3;
    private javax.swing.JRadioButton rbB4;
    private javax.swing.JRadioButton rbC1;
    private javax.swing.JRadioButton rbC2;
    private javax.swing.JRadioButton rbC3;
    private javax.swing.JRadioButton rbC4;
    // End of variables declaration//GEN-END:variables

}
